let question = [[
		"do not litter.",
		"please recycle plastic.",
		"it's time for school.",
		"stay safe while driving.",
		"remember to wash your hand.",
		"it's okay to be loose.",
		"begin with safety in mind.",
		"teamwork make a dreamwork."],[
		]];
console.log(question[0])
let number = 0;
question[0].splice(number,1)

console.log(question[0])

question[0].splice(5,1)

console.log(question[0])